<?php
include 'database/db.php';

$error = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rut = $_POST['rut'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $fecha = $_POST['fecha_nacimiento'];

    // Verificar si el RUT ya existe
    $check = $conn->prepare("SELECT id FROM personas WHERE rut = ?");
    $check->bind_param("s", $rut);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $error = true;
    } else {
        $sql = $conn->prepare("INSERT INTO personas (rut, nombres, apellidos, fecha_nacimiento) VALUES (?, ?, ?, ?)");
        $sql->bind_param("ssss", $rut, $nombres, $apellidos, $fecha);
        $sql->execute();
        header("Location: index.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Agregar Persona</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2>Agregar Persona</h2>
    <form method="POST" class="mt-4">
        <div class="mb-3">
            <label class="form-label">RUT</label>
            <input type="text" name="rut" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nombres</label>
            <input type="text" name="nombres" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Apellidos</label>
            <input type="text" name="apellidos" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Fecha de Nacimiento</label>
            <input type="date" name="fecha_nacimiento" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Guardar</button>
        <a href="index.php" class="btn btn-secondary">Volver</a>
    </form>
</div>

<?php if ($error): ?>
<!-- Modal de Error -->
<div class="modal fade show" id="errorModal" tabindex="-1" style="display:block;" aria-modal="true" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content border-danger">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Error</h5>
        <a href="create.php" class="btn-close"></a>
      </div>
      <div class="modal-body">
        <p>El RUT ingresado ya existe en la base de datos.</p>
      </div>
      <div class="modal-footer">
        <a href="create.php" class="btn btn-secondary">Cerrar</a>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

</body>
</html>
