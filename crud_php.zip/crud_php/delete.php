<?php
include 'database/db.php';
$id = $_GET['id'];

$sql = "DELETE FROM personas WHERE id=$id";
$conn->query($sql);

header("Location: index.php");
exit;
