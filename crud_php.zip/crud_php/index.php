<?php include 'database/db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>CRUD PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="mb-4">Lista de Personas</h2>
    <a href="create.php" class="btn btn-primary mb-3">Agregar Persona</a>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>RUT</th>
                <th>Nombres</th>
                <th>Apellidos</th>
                <th>Fecha Nacimiento</th>
                <th>Edad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM personas";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()):
            $birthDate = new DateTime($row['fecha_nacimiento']);
            $today = new DateTime();
            $edad = $today->diff($birthDate)->y;
        ?>
            <tr>
                <td><?= $row['rut'] ?></td>
                <td><?= $row['nombres'] ?></td>
                <td><?= $row['apellidos'] ?></td>
                <td><?= $row['fecha_nacimiento'] ?></td>
                <td><?= $edad ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Editar</a>
                    <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar?')">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
