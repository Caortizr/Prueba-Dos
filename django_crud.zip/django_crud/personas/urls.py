from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('crear/', views.crear_persona, name='crear_persona'), # Vista para crear una nueva persona
    path('editar/<str:rut>/', views.editar_persona, name='editar_persona'), # Vista para editar una persona
    path('eliminar/<str:rut>/', views.eliminar_persona, name='eliminar_persona'),  # Vista para eliminar una persona
]