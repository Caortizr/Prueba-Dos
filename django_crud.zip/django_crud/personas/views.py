from django.shortcuts import render, redirect, get_object_or_404
from .models import Persona
import re
from django.db import models

def index(request):
    personas = Persona.objects.all()
    return render(request, 'personas/index.html', {'personas': personas})

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Persona

def crear_persona(request): # Vista para crear una nueva persona
    if request.method == 'POST':
        rut = request.POST['rut'].strip().upper()

        # Validar formato RUT (NNNNNNNN-D, donde D es número o K)
        if not re.match(r'^\d{6,8}-[\dkK]$', rut):
            messages.error(request, "Formato de RUT inválido. Usa el formato 12345678-9 o 1234567-K.")
            return redirect('index')

        # Validar duplicado
        if Persona.objects.filter(rut=rut).exists():
            messages.error(request, f"El RUT '{rut}' ya está registrado.")
            return redirect('index')

        # Si esta todo ok se crea el registro
        Persona.objects.create(
            rut=rut,
            nombres=request.POST['nombres'],
            apellidos=request.POST['apellidos'],
            fecha_nacimiento=request.POST['fecha_nacimiento']
        )

    return redirect('index')

# Vista para editar una persona
def editar_persona(request, rut):
    persona = get_object_or_404(Persona, rut=rut)
    if request.method == 'POST':
        persona.nombres = request.POST['nombres']
        persona.apellidos = request.POST['apellidos']
        persona.fecha_nacimiento = request.POST['fecha_nacimiento']
        persona.save()
    return redirect('index')

# Vista para eliminar una persona
def eliminar_persona(request, rut):
    persona = get_object_or_404(Persona, rut=rut)
    persona.delete()
    return redirect('index')

# Vista para mostrar la lista de personas
def index(request):
    personas = Persona.objects.all()
    total_personas = personas.count()
    return render(request, 'personas/index.html', {
        'personas': personas,
        'crear_error': request.GET.get('error', ''),
        'total_personas': total_personas
    })

# Vista para mostrar la lista de personas con búsqueda
def index(request):
    query = request.GET.get('q', '')
    personas = Persona.objects.all()

    # Filtrar por campos RUT o nombres
    if query:
        personas = personas.filter(
            models.Q(rut__icontains=query) | models.Q(nombres__icontains=query) | models.Q(apellidos__icontains=query)
        )

    total_personas = personas.count() # Contar el total de personas después del filtrado

    return render(request, 'personas/index.html', {
        'personas': personas,
        'crear_error': request.GET.get('error', ''),
        'total_personas': total_personas,
        'query': query
    })